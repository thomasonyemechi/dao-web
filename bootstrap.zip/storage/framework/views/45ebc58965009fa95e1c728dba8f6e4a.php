<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Bitech">
    <meta name="keywords" content="dental, dao, dental clinic, clinic, dao dental clinic, akure, ondo,  ">

    <meta name="description"
        content="Welcome to Dao Dental Clinic, where your oral health and comfort are our top priorities. Established with a passion for delivering exceptional dental care, our clinic is dedicated to providing a positive and personalized experience for every patient">


    <title><?php echo e(env('APP_NAME')); ?> | <?php echo $__env->yieldContent('page_title'); ?> </title>

    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/responsive.css')); ?>" rel="stylesheet">
    <link rel="icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon">

</head>

<body class="page-wrapper">
    

    <?php echo $__env->make('layouts.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('page_content'); ?>

    <?php echo $__env->make('layouts.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="scroll-to-top scroll-to-target" data-target=".main-header"><span class="icon fa fa-angle-up"></span>
    </div>

    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-2.1.4.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/isotope.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.fancybox.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.mixitup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/validation.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/wow.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery-ui.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/SmoothScroll.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\dao-web\resources\views/layouts/app.blade.php ENDPATH**/ ?>